package com.example.myapplication_multy2

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier

@Composable
fun AboutScreen() {
    val navigator = LocalNavigator.current

    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("About Screen")
        Button(onClick = { navigator.navigate(MainScreenKey) }) { Text("Go to Main") }
        Button(onClick = { navigator.navigate(ContactScreenKey) }) { Text("Go to Contact") }
        if (navigator.hasPrevious()) {
            Button(onClick = { navigator.pop() }) { Text("Back") }
        }
    }
}