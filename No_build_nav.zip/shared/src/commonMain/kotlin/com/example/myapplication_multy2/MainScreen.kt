package com.example.myapplication_multy2

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier

@Composable
fun MainScreen() {
    val navigator = LocalNavigator.current
    val greeting = remember { Greeting().greet() }

    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("Main Screen")
        Text(greeting)
        Button(onClick = { navigator.navigate(AboutScreenKey) }) { Text("Go to About") }
        Button(onClick = { navigator.navigate(ContactScreenKey) }) { Text("Go to Contact") }
        if (navigator.hasPrevious()) {
            Button(onClick = { navigator.pop() }) { Text("Back") }
        }
    }
}