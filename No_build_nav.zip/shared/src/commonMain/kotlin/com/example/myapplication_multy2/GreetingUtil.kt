package com.example.myapplication_multy2

fun sayHello(to: String): String =
    "Hello, $to!"